import pygame
import numpy as np
import joblib

# Initialize Pygame
pygame.init()

# Set up Pygame window
width, height = 400, 200
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Object Classifier")

# Load your machine learning model here
model = joblib.load('model.ipynb')

# Colors
white = (255, 255, 255)
black = (0, 0, 0)

# Fonts
font = pygame.font.Font(None, 24)

input_text = ""
prediction_text = ""

def predict_object(input_data):
    input_data_as_numpy_array = np.asarray(input_data)
    input_data_reshaped = input_data_as_numpy_array.reshape(1, -1)
    prediction = model.predict(input_data_reshaped)[0]
    return 'The object is a Rock' if prediction == 'R' else 'The object is a Mine'

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                if input_text:
                    prediction_text = predict_object(input_text)
                else:
                    prediction_text = "Please enter data."
                input_text = ""
            elif event.key == pygame.K_BACKSPACE:
                input_text = input_text[:-1]
            else:
                input_text += event.unicode

    screen.fill(white)

    # Display input text
    input_surface = font.render("Input Data: " + input_text, True, black)
    screen.blit(input_surface, (10, 10))

    # Display prediction result
    prediction_surface = font.render(prediction_text, True, black)
    screen.blit(prediction_surface, (10, 60))

    pygame.display.flip()

# Quit Pygame
pygame.quit()
