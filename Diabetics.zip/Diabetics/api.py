from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import json 
import uvicorn

app = FastAPI() #Creating instance of api 

class model_input(BaseModel):

#Giving all the features names except the outcome column 
    Pregnancies : int
    Glucose : int
    BloodPressure : int
    SkinThickness : int
    Insulin : int
    BMI : float
    DiabetesPedigreeFunction : float
    Age : int



diabetes_model = pickle.load(open('diabetes_model.sav', 'rb'))                     #Loading the saved file in local disk 
@app.post("/diabetes_prediction")                                                  #To give values to our api which goes for above column names, End points - ending of our URL. This is end point 
def diabetes_pred(input_parameters : model_input):                                 #input_paramters - what user will give, model_input - dataset features 

    input_data = input_parameters.json()                                           #model_input data will be posted to our api in the form of json. And v convert our json file into dictionary and then v will get an url. user inputs through api will be converted into json and then that json file is converted to dict
    input_dictionary = json.loads(input_data)                                      #Json.loads is converted into dict. input_data is the final dict 



    #Converting into dictionary 
    #Inputs from user are 'keys' and features inside coluns below are 'values'  
    preg = input_dictionary['Pregnancies']
    glu = input_dictionary['Glucose']
    bp = input_dictionary['BloodPressure']
    skin = input_dictionary['SkinThickness']
    insluin = input_dictionary['Insulin']
    bmi = input_dictionary['BMI']
    dpf = input_dictionary['DiabetesPedigreeFunction']
    age = input_dictionary['Age']
    
    #Now we have to convert this dict into dataframe./list
    input_list = [preg, glu, bp, skin, insluin, bmi, dpf, age]  #Now v will be passing this list to the model above

    prediction = diabetes_model.predict([input_list])
    if prediction[0] == 1:
        return "Diabetic"
    else:
        return "Non-Diabetic"

if __name__ == '__main__':
    uvicorn.run(app,port=8000)


